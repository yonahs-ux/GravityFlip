# Gravity Flip v3.0 - Design Decisions

## Key Changes and Why They Matter

### 1. Gradual Gravity Flip (The Core Fix)

**Before (v2.0)**: Player teleported instantly between floor and ceiling.

**After (v3.0)**: Player receives a velocity impulse and travels through space.

```javascript
// Player applies initial velocity, then gravity takes over
flip() {
    this.velocityY = -CONFIG.FLIP_VELOCITY * this.gravityDirection;
    this.isFlipping = true;
    this.isGrounded = false;
}

update() {
    // Gravity accelerates player
    this.velocityY += CONFIG.GRAVITY * this.gravityDirection;
    this.y += this.velocityY;  // GRADUAL movement
}
```

**Why it feels better**:
- Player can collide with obstacles MID-FLIP
- Timing becomes a skill
- Movement is predictable and readable
- Deaths feel earned, not random

---

### 2. Human Character

**Before**: Abstract triangle/shape.

**After**: Stylized person with:
- Visible head, torso, arms, legs
- Running animation (leg/arm swing)
- Rotates with gravity direction

**Why**: Players connect emotionally with humanoid characters. It's clearer what you're controlling.

---

### 3. Three Obstacle Types

| Type | Surface | Shape | Purpose |
|------|---------|-------|---------|
| Spike | Floor/Ceiling | Triangle | Punish wrong surface |
| Block | Floor/Ceiling | Rectangle | Force flip timing |
| Floating | Mid-air | Diamond | Punish mistimed flips |

**Critical addition**: Floating obstacles mean you can die DURING a flip, not just at surfaces. This creates real skill-based gameplay.

---

### 4. Procedural Techno Audio

Rather than bundling large audio files, the game generates techno music in real-time using Web Audio API:

- **Kick drum**: Sine wave with pitch envelope
- **Hi-hat**: Filtered white noise
- **Bass**: Sawtooth oscillator

**Benefits**:
- Zero download size for music
- Perfectly looped
- Works offline

---

### 5. Physics Constants

| Constant | Value | Purpose |
|----------|-------|---------|
| `GRAVITY` | 0.8 | How fast player accelerates |
| `FLIP_VELOCITY` | 15 | Initial impulse on flip |
| `MAX_VELOCITY` | 18 | Terminal velocity cap |

These are tuned for:
- ~0.5 second flip duration
- Readable arc through space
- Time to react to obstacles

---

## Validation Checklist

- [x] Player takes multiple frames to flip
- [x] No Y-position teleportation
- [x] Mid-air collision causes death
- [x] Three obstacle types spawn
- [x] Mute button toggles audio
- [x] Deaths increment counter
- [x] High score persists

Run `window.runGameTests()` in browser console to verify all checks.
